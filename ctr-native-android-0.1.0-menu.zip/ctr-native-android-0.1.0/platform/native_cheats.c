#include "platform/native_config.h"

// Applies the cheats chosen in the settings menu. These reuse the retail cheat
// flags (see game/230/MM_CheatCodes.c): the race flags live in gGT->gameMode2
// and are consumed by VehBirth/VehPhys*, the unlocks live in the save progress.
// Everything here only ORs bits in, so calling it every frame is harmless.

void NativeCheats_Apply(void)
{
	uint32_t mask = g_nativeConfig.cheatMask;
	struct GameTracker *gGT;

	if (mask == 0u)
		return;

	gGT = sdata->gGT;
	if (gGT != NULL)
	{
		u32 flags = 0;

		if (mask & NATIVE_CHEAT_MAX_WUMPA)        flags |= CHEAT_WUMPA;
		if (mask & NATIVE_CHEAT_INFINITE_MASKS)   flags |= CHEAT_MASK;
		if (mask & NATIVE_CHEAT_MAX_TURBOS)       flags |= CHEAT_TURBO;
		if (mask & NATIVE_CHEAT_MAX_BOMBS)        flags |= CHEAT_BOMBS;
		if (mask & NATIVE_CHEAT_INVISIBLE)        flags |= CHEAT_INVISIBLE;
		if (mask & NATIVE_CHEAT_SUPER_ENGINE)     flags |= CHEAT_ENGINE;
		if (mask & NATIVE_CHEAT_SUPER_TURBO_PADS) flags |= CHEAT_TURBOPAD;
		if (mask & NATIVE_CHEAT_ICY_TRACKS)       flags |= CHEAT_ICY;
		if (mask & NATIVE_CHEAT_ONE_LAP)          flags |= CHEAT_ONELAP;
		if (mask & NATIVE_CHEAT_TURBO_COUNTER)    flags |= CHEAT_TURBOCOUNT;
		if (mask & NATIVE_CHEAT_ADV_DIFFICULTY)   flags |= CHEAT_ADV;
		if (mask & NATIVE_CHEAT_SUPER_HARD)       flags |= CHEAT_SUPERHARD;

		gGT->gameMode2 |= flags;
	}

	// NOTE: unlocks are written into the in-memory save progress, so they end up
	// in the memory card save the next time the game saves.
	if (mask & NATIVE_CHEAT_UNLOCK_ROO)         sdata->gameProgress.unlockFlags |= UNLOCK_ROO;
	if (mask & NATIVE_CHEAT_UNLOCK_PAPU)        sdata->gameProgress.unlockFlags |= UNLOCK_PAPU;
	if (mask & NATIVE_CHEAT_UNLOCK_JOE)         sdata->gameProgress.unlockFlags |= UNLOCK_JOE;
	if (mask & NATIVE_CHEAT_UNLOCK_PINSTRIPE)   sdata->gameProgress.unlockFlags |= UNLOCK_PINSTRIPE;
	if (mask & NATIVE_CHEAT_UNLOCK_FAKE_CRASH)  sdata->gameProgress.unlockFlags |= UNLOCK_FAKE_CRASH;
	if (mask & NATIVE_CHEAT_UNLOCK_PENTA)       sdata->gameProgress.unlockFlags |= UNLOCK_PENTA;
	if (mask & NATIVE_CHEAT_UNLOCK_TROPY)       sdata->gameProgress.unlockFlags |= UNLOCK_TROPY;
	if (mask & NATIVE_CHEAT_UNLOCK_TRACKS)      sdata->gameProgress.unlockFlags |= GAME_UNLOCK_TRACKS_MASK;
	if (mask & NATIVE_CHEAT_UNLOCK_SCRAPBOOK)   UNLOCK_ADV_BIT(sdata->gameProgress.unlocks, GAME_UNLOCK_BIT_SCRAPBOOK);
}
