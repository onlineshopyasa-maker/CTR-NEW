#include "platform/native_config.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct NativeConfig g_nativeConfig = {0, 0, 0u};

struct NativeCheatKey
{
	const char *name;
	uint32_t bit;
};

static const struct NativeCheatKey s_cheatKeys[] = {
    {"max_wumpa", NATIVE_CHEAT_MAX_WUMPA},
    {"infinite_masks", NATIVE_CHEAT_INFINITE_MASKS},
    {"max_turbos", NATIVE_CHEAT_MAX_TURBOS},
    {"max_bombs", NATIVE_CHEAT_MAX_BOMBS},
    {"invisible", NATIVE_CHEAT_INVISIBLE},
    {"super_engine", NATIVE_CHEAT_SUPER_ENGINE},
    {"super_turbo_pads", NATIVE_CHEAT_SUPER_TURBO_PADS},
    {"icy_tracks", NATIVE_CHEAT_ICY_TRACKS},
    {"one_lap", NATIVE_CHEAT_ONE_LAP},
    {"turbo_counter", NATIVE_CHEAT_TURBO_COUNTER},
    {"adv_difficulty", NATIVE_CHEAT_ADV_DIFFICULTY},
    {"super_hard", NATIVE_CHEAT_SUPER_HARD},
    {"unlock_roo", NATIVE_CHEAT_UNLOCK_ROO},
    {"unlock_papu", NATIVE_CHEAT_UNLOCK_PAPU},
    {"unlock_joe", NATIVE_CHEAT_UNLOCK_JOE},
    {"unlock_pinstripe", NATIVE_CHEAT_UNLOCK_PINSTRIPE},
    {"unlock_fake_crash", NATIVE_CHEAT_UNLOCK_FAKE_CRASH},
    {"unlock_penta", NATIVE_CHEAT_UNLOCK_PENTA},
    {"unlock_tropy", NATIVE_CHEAT_UNLOCK_TROPY},
    {"unlock_tracks", NATIVE_CHEAT_UNLOCK_TRACKS},
    {"unlock_scrapbook", NATIVE_CHEAT_UNLOCK_SCRAPBOOK},
};

static int NativeConfig_IsSpace(char c)
{
	return (c == ' ') || (c == '\t') || (c == '\r');
}

static int NativeConfig_ApplyKey(struct NativeConfig *out, const char *key, size_t keyLen, int value)
{
	size_t i;

	if ((keyLen == 15) && (strncmp(key, "graphics.filter", 15) == 0))
	{
		out->bilinear = (value != 0);
		return 1;
	}
	if ((keyLen == 14) && (strncmp(key, "display.aspect", 14) == 0))
	{
		out->stretch = (value != 0);
		return 1;
	}
	if ((keyLen > 6) && (strncmp(key, "cheat.", 6) == 0))
	{
		for (i = 0; i < sizeof(s_cheatKeys) / sizeof(s_cheatKeys[0]); i++)
		{
			if ((strlen(s_cheatKeys[i].name) == keyLen - 6) && (strncmp(key + 6, s_cheatKeys[i].name, keyLen - 6) == 0))
			{
				if (value != 0)
					out->cheatMask |= s_cheatKeys[i].bit;
				else
					out->cheatMask &= ~s_cheatKeys[i].bit;
				return 1;
			}
		}
	}
	return 0;
}

int NativeConfig_Parse(const char *text, unsigned long length, struct NativeConfig *out)
{
	unsigned long pos = 0;
	int recognised = 0;

	if ((text == NULL) || (out == NULL))
		return 0;

	while (pos < length)
	{
		unsigned long lineStart = pos;
		unsigned long lineEnd;
		const char *eq;
		const char *keyBegin;
		const char *keyEnd;
		const char *valBegin;
		const char *valEnd;
		char valueBuf[16];
		size_t valueLen;

		while ((pos < length) && (text[pos] != '\n'))
			pos++;
		lineEnd = pos;
		if (pos < length)
			pos++; // skip '\n'

		keyBegin = text + lineStart;
		valEnd = text + lineEnd;
		while ((keyBegin < valEnd) && NativeConfig_IsSpace(*keyBegin))
			keyBegin++;
		if ((keyBegin >= valEnd) || (*keyBegin == '#'))
			continue;

		eq = (const char *)memchr(keyBegin, '=', (size_t)(valEnd - keyBegin));
		if (eq == NULL)
			continue;

		keyEnd = eq;
		while ((keyEnd > keyBegin) && NativeConfig_IsSpace(keyEnd[-1]))
			keyEnd--;
		valBegin = eq + 1;
		while ((valBegin < valEnd) && NativeConfig_IsSpace(*valBegin))
			valBegin++;
		while ((valEnd > valBegin) && NativeConfig_IsSpace(valEnd[-1]))
			valEnd--;

		valueLen = (size_t)(valEnd - valBegin);
		if ((keyEnd == keyBegin) || (valueLen == 0) || (valueLen >= sizeof(valueBuf)))
			continue;
		memcpy(valueBuf, valBegin, valueLen);
		valueBuf[valueLen] = '\0';

		recognised += NativeConfig_ApplyKey(out, keyBegin, (size_t)(keyEnd - keyBegin), atoi(valueBuf));
	}

	return recognised;
}

int NativeConfig_Load(const char *baseDir)
{
	char path[1024];
	FILE *file;
	char *buffer;
	long size;
	size_t got;

	if ((baseDir == NULL) || (baseDir[0] == '\0'))
		return 0;
	if (snprintf(path, sizeof(path), "%s/settings.cfg", baseDir) >= (int)sizeof(path))
		return 0;

	file = fopen(path, "rb");
	if (file == NULL)
		return 0;

	fseek(file, 0, SEEK_END);
	size = ftell(file);
	fseek(file, 0, SEEK_SET);
	if ((size <= 0) || (size > 64 * 1024))
	{
		fclose(file);
		return 0;
	}

	buffer = (char *)malloc((size_t)size);
	if (buffer == NULL)
	{
		fclose(file);
		return 0;
	}
	got = fread(buffer, 1, (size_t)size, file);
	fclose(file);

	NativeConfig_Parse(buffer, (unsigned long)got, &g_nativeConfig);
	free(buffer);
	return 1;
}
